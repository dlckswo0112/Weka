package interface2;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.Filter;

public class WekaAPI {
	/** the classifier used internally */
	protected Classifier m_Classifier = null;

	/** the filter to use */
	protected Filter m_Filter = null;

	/** the training file */
	protected DataSource m_TrainingFile = null;

	/** the training instances */
	protected Instances m_Training = null;

	/** for evaluating the classifier */
	protected Evaluation m_Evaluation = null;

	private String[] lastResult = null;
	
	private boolean build = false;

	public WekaAPI() {
		super();
		
		lastResult = new String[3];
	}

	public WekaAPI(WekaAPI src) {
		m_Classifier = src.m_Classifier;
		m_Filter = src.m_Filter;
		m_TrainingFile = src.m_TrainingFile;
		m_Training = src.m_Training;
		m_Evaluation = src.m_Evaluation;
		lastResult = src.lastResult;
		build = src.build;
	}

	public boolean setModel(String modelName, String option) throws Exception {
		m_Classifier = null;
		for (String function : Keyword.FUNCTION_DICTIONARY) {
			if (modelName.equals(function)) {
				m_Classifier = Keyword.getModel(function, option);
				break;
			}
		}
		
		if (m_Classifier.equals(null))
			return false;
		
		return true;
	}
	
	public boolean setData(String dataFile) throws Exception {
		m_TrainingFile = new DataSource(dataFile);
		
		if (m_TrainingFile.equals(null))
			return false;
		
		return true;
	}
	
	public boolean setTraining() throws Exception {
		m_Training = m_TrainingFile.getDataSet();
		m_Training.setClassIndex(m_Training.numAttributes() - 1);
		
		if(m_Training.equals(null))
			return false;
		
		return true;
	}
	
	public boolean buildModel(String modelName, String option, String dataFile) throws Exception {
		boolean result = false;
		if(setModel(modelName, option) && setData(dataFile) && setTraining())
			result = true;
		
		m_Classifier.buildClassifier(m_Training);
		build = true;
		
		return result;
	}
	
	public boolean isBuild() {
		return build;
	}
	
	public String[] getLastResult() {
		return lastResult;
	}
	
	protected void setLastResult(String modelString, String detailString, String summaryString) {
		lastResult[0] = modelString;
		lastResult[1] = detailString;
		lastResult[2] = summaryString;
	}
	
	public String[] runCrossValidation(int fold, int seed) throws Exception {
		if(!isBuild())
			return null;
		
		StringBuffer detail = new StringBuffer();

		Evaluation validation = new Evaluation(m_Training);
		validation.crossValidateModel(m_Classifier, m_Training, fold, m_Training.getRandomNumberGenerator(seed), detail, null, true);

		setLastResult(m_Classifier.toString(), detail.toString(), validation.toSummaryString());

		return lastResult;
	}
	
	public String[] runTestSet(String path) throws Exception {
		if(!isBuild())
			return null;
		
		DataSource testData = new DataSource(path);
		Instances testSet = testData.getDataSet();
		testSet.setClassIndex(testSet.numAttributes() - 1);
		
		if(testSet.equals(null))
			return null;
		
		StringBuffer detail = new StringBuffer();
		
		Evaluation validation = new Evaluation(m_Training);
		validation.evaluateModel(m_Classifier, testSet, detail, null, true);

		setLastResult(m_Classifier.toString(), detail.toString(), validation.toSummaryString());

		return lastResult;
	}

	public static void main(String[] args) throws Exception {
		WekaAPI w = new WekaAPI();
		String function = "GP";
		String option = "-L 1.0 -N 0 -K \"weka.classifiers.functions.supportVector.RBFKernel -C 250007 -G 1.0\"";
		String dataFile = "resource/data/cpu.arff";
		int fold = 10;
		int seed = 1;

		w.buildModel(function, option, dataFile);
		//String[] result = w.runCrossValidation(fold, seed);
		String[] result = w.runTestSet("resource/data/cpu.arff");
		System.out.println(result[0]);
		System.out.println(result[1]);
		System.out.println(result[2]);
	}
	
	public boolean saveModel(String path) {
		if(!isBuild())
			return false;
		
		File sFile = new File(path);

		OutputStream os;
		try {
			os = new FileOutputStream(sFile);
			if (sFile.getName().endsWith(".gz")) {
				os = new GZIPOutputStream(os);
			}
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(os);
			objectOutputStream.writeObject(m_Classifier);
			m_Training = m_Training.stringFreeStructure();
			if (m_Training != null) {
				objectOutputStream.writeObject(m_Training);
			}
			objectOutputStream.flush();
			objectOutputStream.close();
			
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			return false;
		}
	}
}