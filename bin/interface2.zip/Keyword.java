package interface2;

import weka.classifiers.Classifier;
import weka.classifiers.functions.GaussianProcesses;
import weka.classifiers.functions.RBFNetwork;
import weka.classifiers.functions.SMO;

public class Keyword {
	public static String[] FUNCTION_DICTIONARY = { "GP", "RBFN", "SVM", "DNN" };

	public static String PreClassifier = "weka.classifiers.";
	public static String PreFilter = "weka.filters.";

	public static String GP = "functions.GaussianProcesses";
	public static String RBFN = "functions.RBFNetwork";
	public static String SVM = "functions.SMO";
	public static String DNN = "";

	public static Classifier getModel(String function, String option) throws Exception {
		if (option.equals("")) {
			if (function.equals("GP"))
				option = "-L 1.0 -N 0 -K \"weka.classifiers.functions.supportVector.RBFKernel -C 250007 -G 1.0\"";
			else if (function.equals("RBFN"))
				option = "-B 2 -S 1 -R 1.0E-8 -M -1 -W 0.1";
			else if (function.equals("SVM"))
				option = "-C 1.0 -L 0.001 -P 1.0E-12 -N 0 -V -1 -W 1 -K \"weka.classifiers.functions.supportVector.PolyKernel -C 250007 -E 1.0\"";
			else if (function.equals("DNN"))
				option = "";
			else
				return null;
		}
		
		String[] options = weka.core.Utils.splitOptions(option);

		if (function.equals("GP"))
			return Classifier.forName(PreClassifier + GP, options);
		else if (function.equals("RBFN"))
			return Classifier.forName(PreClassifier + RBFN, options);
		else if (function.equals("SVM"))
			return Classifier.forName(PreClassifier + SVM, options);
		else if (function.equals("DNN"))
			return Classifier.forName(PreClassifier + DNN, options);
		else
			return null;
	}
}
