package interface2;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

import weka.classifiers.Classifier;
import weka.core.Instances;

public class Util {

	public void saveModel(Classifier classifier, Instances data, String path) {
		File sFile = new File(path);

		OutputStream os;
		try {
			os = new FileOutputStream(sFile);
			if (sFile.getName().endsWith(".gz")) {
				os = new GZIPOutputStream(os);
			}
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(os);
			objectOutputStream.writeObject(classifier);
			data = data.stringFreeStructure();
			if (data != null) {
				objectOutputStream.writeObject(data);
			}
			objectOutputStream.flush();
			objectOutputStream.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
